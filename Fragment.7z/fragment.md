<h2>Fragmrnt</h2>
<h2>1. 基本概念</h2><br>
   Fragmnet是Android3.0后引入的一个新的API，我们可以把他看成一个小型的Activity，又称为Activity片段！
   另外Fragment并不能单独的使用，它需要嵌套在Activity中使用,尽管他拥有这自己的生命周期，还是会受到宿主
   Activity生命周期的影响，比如Activity别destory销毁了，他也会跟着销毁！<br>
<br>
<h3>1.1 生命周期<br></h3>
<br>
![](http://www.runoob.com/wp-content/uploads/2015/08/31722863.jpg)<br>
<br>
<ul><li>Fragment的生命周期和Activity有点类似:<br>三种状态:<br>
(1) Resumed:在允许中的Fragment可见<br>
(2) Paused:所在Activity可见,但是得不到焦点<br>
(3) Stoped:
①调用addToBackStack(),Fragment被添加到Bcak栈
②该Activity转向后台,或者该Fragment被替换/删除<br>
ps:停止状态的fragment仍然活着(所有状态和成员信息被系统保持着),然而,它对用户
不再可见,并且如果activity被干掉,他也会被干掉.</li></ul>

<h3>1.2 Fragment的子类</h3>
<blockquote><ul>
<li>对话框:<strong>DialogFragment</strong></li>
<li>列表:<strong>ListFragment</strong></li>
<li>选项设置:<strong>PreferenceFragment</strong></li>
<li>WebView界面:<strong>WebViewFragment</strong></li>
</ul>
</blockquote>
<h2>2. Fragment的子类</h2>
<h3>2.1 创建Fragment</h3>
<li>静态加载Fragment</li><br>

```
public class Fragmentone extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment1, container,false);
        return view;
    }   
}
```
<li>动态加载Fragment</li>
<br>
<font color="ff0000">流程图</font><br><br>

![](http://www.runoob.com/wp-content/uploads/2015/08/29546434.jpg)
